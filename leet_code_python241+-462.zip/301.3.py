class Solution:
    def removeInvalidParentheses(self, s: str) :

        def removeInvalidParentheses(self, s):


            level = {s}
            while True:
                valid = []
                for s in level:
                    try:
                        eval('0,' + filter('()'.count, s).replace(')', '),'))
                        valid.append(s)
                    except:
                        pass
                if valid:
                    return valid
                level = {s[:i] + s[i + 1:] for s in level for i in range(len(s))}
sol = Solution()
s = ")()"
print(sol.removeInvalidParentheses(s))