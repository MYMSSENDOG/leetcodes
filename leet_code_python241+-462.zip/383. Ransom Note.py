class Solution:
    def canConstruct(self, ransomNote: str, magazine: str) -> bool:
