class Solution:
    def isAnagram(self, s: str, t: str) -> bool:

        return s == t

sol = Solution()
s = "asdf"
t = "fdsa"
print(sol.isAnagram(s,t))