"""
macro start
while 1 :
    find cancel and use button
    if not find, wait
    if find
         str = get str * 1.5
            if color == red:
                str *=-1
         health = get health * 1.2
         do same reamins.

         if sum of stat >0:
            click use button
         else:
            click cancel button
            wait 2000
            cilck start button

"""