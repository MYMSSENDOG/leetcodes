class Solution:
    def maximumTip(self, time, profit):



sol = Solution()
time=[[1,2,3,4],[1,2,3,4],[5,6,7,8],[5,3,4,8]]
profit = [[1,1,1,1], [5,2,2,3], [7,6,6,5], [9,10,10,10]]
print(sol.maximumTip(time, profit))